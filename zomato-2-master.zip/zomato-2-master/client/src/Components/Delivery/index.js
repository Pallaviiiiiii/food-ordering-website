import React from "react";
import DeliveryCarousal from "./DeliveryCarousal";

const Delivery = () => {
  return (
    <>
      <DeliveryCarousal />
    </>
  )
};

export default Delivery;
